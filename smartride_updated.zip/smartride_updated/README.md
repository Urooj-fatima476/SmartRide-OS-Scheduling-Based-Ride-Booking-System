# 🚗 SmartRide — OS Scheduling Algorithms Ride Booking System

A complete InDrive/Uber-style ride booking system that demonstrates **4 Operating System CPU Scheduling Algorithms** applied to real-world ride dispatch.

---

## 📁 Folder Structure

```
smartride/
├── app.py                   # Main Flask backend (all routes + OS algorithms)
├── requirements.txt         # Python dependencies
├── smartride.db             # SQLite database (auto-created on first run)
│
├── templates/               # HTML templates (Jinja2)
│   ├── base.html            # Shared layout, navbar, styles
│   ├── login.html           # Login page
│   ├── register.html        # Registration page
│   ├── dashboard.html       # User home dashboard
│   ├── book.html            # Ride booking + algorithm selection
│   ├── ride_status.html     # Live ride tracking page
│   ├── history.html         # Ride history
│   ├── admin.html           # Admin dashboard with charts
│   ├── queue.html           # Live queue visualizer
│   ├── drivers.html         # Driver fleet management
│   └── driver.html          # Individual driver dashboard
│
└── static/                  # Static assets (CSS/JS if extended)
    ├── css/
    └── js/
```

---

## ⚙️ Installation & Setup

### Step 1 — Prerequisites
Make sure you have **Python 3.8+** installed:
```bash
python --version
```

### Step 2 — Clone / Extract Project
```bash
# If downloaded as ZIP:
unzip smartride.zip
cd smartride
```

### Step 3 — Create Virtual Environment (Recommended)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 4 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5 — Run the Application
```bash
python app.py
```

### Step 6 — Open in Browser
```
http://localhost:5000
```

---

## 🔐 Demo Credentials

| Role  | Email                  | Password  |
|-------|------------------------|-----------|
| User  | user@smartride.com     | user123   |
| Admin | admin@smartride.com    | admin123  |

---

## 🧠 OS Scheduling Algorithms Explained

### 1. ⚡ Priority Scheduling
- **Concept**: Each ride is assigned a priority number. Lower number = higher priority.
- **Emergency** → Priority 1 (highest)
- **Premium** → Priority 2
- **Normal** → Priority 3 (lowest)
- **Tie-breaking**: Within same priority, FCFS order (arrival time) is used.
- **OS Analogy**: Like interrupt-driven process scheduling — critical system processes preempt lower-priority ones.
- **Real-world**: Emergency vehicles clearing traffic; ICU patients before routine checkups.

### 2. 📋 FCFS (First Come First Served)
- **Concept**: Pure queue — whoever requests first gets served first. No priority differences.
- **Implementation**: `ORDER BY arrival_time ASC`
- **Pros**: Simple, no starvation, fair.
- **Cons**: "Convoy effect" — a long ride can block many short ones.
- **OS Analogy**: Basic FIFO process queue in batch systems.
- **Real-world**: Queue at a government office.

### 3. 🔄 Round Robin (Quantum = 3 minutes)
- **Concept**: Scheduler cycles through all ride types in rotation — Emergency → Premium → Normal → Emergency → ...
- **Time Quantum**: Each type gets 3 minutes of dispatch attention.
- **Prevents starvation**: No ride type is ever ignored for long.
- **OS Analogy**: Time-sharing OS — each process gets CPU time in rotation.
- **Real-world**: Load balancing in web servers; restaurant serving tables in rotation.

### 4. 🗺️ SJF (Shortest Job First)
- **Concept**: Ride with shortest distance (burst time) is dispatched first.
- **Burst Time** = Estimated trip distance in km
- **Minimises** average waiting time (mathematically optimal for throughput).
- **Downside**: Long trips may starve if short trips keep arriving.
- **OS Analogy**: Scheduling short CPU bursts first to minimise average turnaround.
- **Real-world**: Printer queue ordering short documents first.

---

## 🤖 Smart Driver Selection Algorithm

Beyond ride scheduling, the system also applies smart logic to **choose the best driver**:

```python
score = (distance * 0.5) - (wait_bonus * 2) - (rating * 0.1)
```

| Factor | Weight | Logic |
|--------|--------|-------|
| Distance to pickup | 50% | Nearest driver preferred (SJF principle) |
| Wait time | 30% bonus | Longer-waiting drivers get priority boost |
| Rating | 20% bonus | Higher-rated drivers slightly preferred |

**Lower score = better match.** This combines FCFS fairness (wait time) with SJF efficiency (nearest driver).

---

## 🌐 Application Pages

| URL | Description |
|-----|-------------|
| `/` | Redirect to login |
| `/login` | Login page |
| `/register` | New user registration |
| `/dashboard` | User home — active & recent rides |
| `/book` | Book a ride — select type + algorithm |
| `/ride/<id>` | Live ride status & tracking |
| `/history` | Full ride history with filters |
| `/admin` | Admin dashboard with charts |
| `/admin/queue` | Live queue with algorithm switcher |
| `/admin/drivers` | Driver fleet overview |
| `/driver/<id>` | Individual driver dashboard |

---

## 🔌 REST API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/queue?algorithm=priority` | GET | Get queue sorted by chosen algorithm |
| `/api/ride/<id>` | GET | Get ride details |
| `/api/ride/<id>/status` | POST | Update ride status |
| `/api/stats` | GET | Aggregated stats (type, algo, status, revenue) |
| `/api/drivers` | GET | All drivers with status |
| `/api/simulate` | GET | Auto-simulate a random ride |
| `/api/auto_complete` | GET | Auto-complete old assigned rides |

---

## 🗄️ Database Schema

### `users` — Registered users and admins
### `drivers` — Driver fleet with GPS, rating, wait_time
### `rides` — All bookings with algorithm, priority, burst_time, ETA, fare
### `queue_log` — Event log for every ride state change

---

## 🎯 Ride Types & Pricing

| Type | Priority | Base Fare | Per KM | Speed |
|------|----------|-----------|--------|-------|
| Emergency 🚨 | 1 | Rs 150 | Rs 35 | 60 km/h |
| Premium ⭐ | 2 | Rs 100 | Rs 25 | 45 km/h |
| Normal 🚗 | 3 | Rs 50 | Rs 15 | 35 km/h |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3 + Flask |
| Database | SQLite (via built-in `sqlite3`) |
| Frontend | HTML5 + Bootstrap 5 + Chart.js |
| Styling | Custom CSS with CSS variables (dark theme) |
| Icons | Font Awesome 6 |
| Fonts | Google Fonts (Space Grotesk + Syne) |
| Charts | Chart.js 4 |

---

## 🔄 Demo Workflow

1. **Login** as `user@smartride.com`
2. Click **Book a Ride**
3. Select ride type: Emergency / Premium / Normal
4. Choose an **OS algorithm**: Priority / FCFS / Round Robin / SJF
5. Click Book — system finds best driver automatically
6. Track ride on `/ride/<id>`
7. **Login as admin** (`admin@smartride.com`) to see:
   - Admin dashboard with live charts
   - Live queue visualizer (switch algorithms in real-time)
   - Driver fleet management
8. Click **Simulate Ride** to auto-add rides for testing
9. On `/admin/queue`, switch between algorithms and watch the queue reorder

---

## 📝 Notes

- The SQLite database (`smartride.db`) is auto-created on first `python app.py` run.
- GPS coordinates are randomised around Karachi for demo purposes.
- In production, integrate Google Maps API for real geocoding.
- The system is single-file backend for simplicity — easy to extend to blueprints.
