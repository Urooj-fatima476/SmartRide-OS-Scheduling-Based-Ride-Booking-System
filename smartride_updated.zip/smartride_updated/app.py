"""
SmartRide - OS Scheduling Algorithms based Ride Booking System
============================================================
Algorithms:
  1. Priority Scheduling  - Emergency > Premium > Normal
  2. FCFS                 - First Come First Served
  3. Round Robin          - Time-quantum based fair scheduling
  4. SJF                  - Shortest Job First (nearest driver)
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import sqlite3, random, math, json
from datetime import datetime

app = Flask(__name__)
app.secret_key = "smartride_os_2024"
DB = "smartride.db"

# ─── DATABASE ───────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db(); c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL, phone TEXT, password TEXT NOT NULL,
        role TEXT DEFAULT 'user', created_at TEXT DEFAULT (datetime('now')))""")
    c.execute("""CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
        phone TEXT, vehicle TEXT, lat REAL DEFAULT 0, lng REAL DEFAULT 0,
        status TEXT DEFAULT 'available', rating REAL DEFAULT 4.5,
        wait_time INTEGER DEFAULT 0, total_rides INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now')))""")
    c.execute("""CREATE TABLE IF NOT EXISTS rides (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, driver_id INTEGER,
        ride_type TEXT, status TEXT DEFAULT 'queued', pickup TEXT, dropoff TEXT,
        pickup_lat REAL, pickup_lng REAL, dropoff_lat REAL, dropoff_lng REAL,
        priority INTEGER, fare REAL, distance REAL, eta INTEGER,
        algorithm TEXT, burst_time INTEGER, arrival_time TEXT,
        start_time TEXT, end_time TEXT, created_at TEXT DEFAULT (datetime('now')),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(driver_id) REFERENCES drivers(id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS queue_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ride_id INTEGER, event TEXT,
        algorithm TEXT, timestamp TEXT DEFAULT (datetime('now')))""")

    c.execute("INSERT OR IGNORE INTO users(name,email,password,role) VALUES(?,?,?,?)",
              ("Admin","admin@smartride.com","admin123","admin"))
    c.execute("INSERT OR IGNORE INTO users(name,email,phone,password,role) VALUES(?,?,?,?,?)",
              ("Demo User","user@smartride.com","0311-9999999","user123","user"))

    drivers = [
        ("Ali Khan","0300-1111111","Toyota Corolla",24.860,67.010,"available",4.8,0),
        ("Sara Ahmed","0301-2222222","Honda Civic",24.870,67.020,"available",4.6,5),
        ("Usman Raza","0302-3333333","Suzuki Alto",24.855,67.005,"available",4.3,12),
        ("Fatima Noor","0303-4444444","Hyundai Tucson",24.880,67.030,"available",4.9,2),
        ("Bilal Mir","0304-5555555","Toyota Vitz",24.850,67.015,"available",4.5,8),
        ("Hina Shah","0305-6666666","Kia Picanto",24.865,67.025,"available",4.7,3),
        ("Tariq Butt","0306-7777777","Daihatsu Mira",24.845,66.998,"busy",4.2,0),
        ("Zara Malik","0307-8888888","Honda BRV",24.875,67.035,"available",4.9,15),
    ]
    for d in drivers:
        c.execute("INSERT OR IGNORE INTO drivers(name,phone,vehicle,lat,lng,status,rating,wait_time) VALUES(?,?,?,?,?,?,?,?)", d)
    conn.commit(); conn.close()

def fetch_all(sql, params=()):
    conn = get_db(); rows = conn.execute(sql, params).fetchall(); conn.close()
    return [dict(r) for r in rows]

def fetch_one(sql, params=()):
    conn = get_db(); row = conn.execute(sql, params).fetchone(); conn.close()
    return dict(row) if row else None

def execute_db(sql, params=()):
    conn = get_db(); cur = conn.execute(sql, params); conn.commit()
    lid = cur.lastrowid; conn.close(); return lid

def log_queue(ride_id, event, algorithm):
    execute_db("INSERT INTO queue_log(ride_id,event,algorithm) VALUES(?,?,?)",(ride_id,event,algorithm))

# ─── OS SCHEDULING ALGORITHMS ───────────────────────────────────────────────

class RideScheduler:
    QUANTUM = 3

    @staticmethod
    def get_priority(ride_type):
        return {"emergency":1,"premium":2,"normal":3}.get(ride_type,3)

    @staticmethod
    def haversine(lat1,lon1,lat2,lon2):
        R=6371; phi1,phi2=math.radians(lat1),math.radians(lat2)
        dphi=math.radians(lat2-lat1); dlambda=math.radians(lon2-lon1)
        a=math.sin(dphi/2)**2+math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
        return R*2*math.atan2(math.sqrt(a),math.sqrt(1-a))

    @staticmethod
    def priority_schedule(rides):
        """Priority Scheduling: Emergency(1) > Premium(2) > Normal(3). Ties broken by arrival time."""
        return sorted(rides, key=lambda r:(r["priority"], r.get("arrival_time","")))

    @staticmethod
    def fcfs_schedule(rides):
        """FCFS: First Come First Served — purely by arrival/request time."""
        return sorted(rides, key=lambda r: r.get("arrival_time",""))

    @staticmethod
    def round_robin_schedule(rides, quantum=3):
        """Round Robin: cycles Emergency→Premium→Normal with time quantum slices."""
        buckets={"emergency":[],"premium":[],"normal":[]}
        for r in rides: buckets[r["ride_type"]].append(r)
        result,visited=[],set()
        types=["emergency","premium","normal"]
        idx={t:0 for t in types}
        max_rounds=max((len(v) for v in buckets.values()),default=0)
        for _ in range(max_rounds):
            for t in types:
                if idx[t]<len(buckets[t]):
                    ride=buckets[t][idx[t]]
                    if ride["id"] not in visited:
                        r=dict(ride); r["quantum"]=quantum
                        result.append(r); visited.add(ride["id"])
                    idx[t]+=1
        return result

    @staticmethod
    def sjf_schedule(rides):
        """SJF: Shortest Job First — shortest trip distance dispatched first. Minimises avg wait time."""
        return sorted(rides, key=lambda r: r.get("burst_time",99))

    @classmethod
    def select_best_driver(cls, drivers, ride, algorithm):
        available=[d for d in drivers if d["status"]=="available"]
        if not available: return None
        plat=ride.get("pickup_lat",24.86); plng=ride.get("pickup_lng",67.01)
        scored=[]
        for d in available:
            dist=cls.haversine(d["lat"],d["lng"],plat,plng)
            wait_bonus=min(d["wait_time"]/20,1.0)
            score=(dist*0.5)-(wait_bonus*2)-(d["rating"]*0.1)
            scored.append((score,dist,d))
        scored.sort(key=lambda x:x[0])
        _,best_dist,best=scored[0]
        best=dict(best); best["distance_to_pickup"]=round(best_dist,2)
        return best

    @classmethod
    def estimate_eta(cls,dist_km,ride_type):
        speeds={"emergency":60,"premium":45,"normal":35}
        return max(1,int((dist_km/speeds.get(ride_type,35))*60))

    @classmethod
    def calculate_fare(cls,dist_km,ride_type):
        base={"emergency":150,"premium":100,"normal":50}
        per_km={"emergency":35,"premium":25,"normal":15}
        return round(base.get(ride_type,50)+(dist_km*per_km.get(ride_type,15)),2)

scheduler=RideScheduler()

# ─── AUTH ROUTES ────────────────────────────────────────────────────────────

@app.route("/")
def index(): return redirect(url_for("login"))

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        email=request.form.get("email","").strip()
        pwd=request.form.get("password","").strip()
        user=fetch_one("SELECT * FROM users WHERE email=? AND password=?",(email,pwd))
        if user:
            session["user_id"]=user["id"]; session["user_name"]=user["name"]; session["role"]=user["role"]
            return redirect(url_for("admin_dashboard") if user["role"]=="admin" else url_for("dashboard"))
        return render_template("login.html",error="Invalid credentials")
    return render_template("login.html")

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        try:
            execute_db("INSERT INTO users(name,email,phone,password) VALUES(?,?,?,?)",
                (request.form.get("name","").strip(), request.form.get("email","").strip(),
                 request.form.get("phone","").strip(), request.form.get("password","").strip()))
            return redirect(url_for("login"))
        except: return render_template("register.html",error="Email already exists")
    return render_template("register.html")

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))

# ─── USER ROUTES ────────────────────────────────────────────────────────────

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session: return redirect(url_for("login"))
    rides=fetch_all("SELECT r.*,d.name as driver_name,d.vehicle,d.phone as driver_phone FROM rides r LEFT JOIN drivers d ON r.driver_id=d.id WHERE r.user_id=? ORDER BY r.created_at DESC LIMIT 10",(session["user_id"],))
    return render_template("dashboard.html",rides=rides,user=session)

@app.route("/book",methods=["GET","POST"])
def book_ride():
    if "user_id" not in session: return redirect(url_for("login"))
    if request.method=="POST":
        data=request.get_json() or request.form
        ride_type=data.get("ride_type","normal")
        pickup=data.get("pickup",""); dropoff=data.get("dropoff","")
        pickup_lat=float(data.get("pickup_lat",24.86+random.uniform(-0.02,0.02)))
        pickup_lng=float(data.get("pickup_lng",67.01+random.uniform(-0.02,0.02)))
        dropoff_lat=float(data.get("dropoff_lat",24.88+random.uniform(-0.02,0.02)))
        dropoff_lng=float(data.get("dropoff_lng",67.03+random.uniform(-0.02,0.02)))
        # Auto-select algorithm based on ride type
        ride_type_algo_map = {"emergency": "priority", "premium": "rr", "normal": "fcfs"}
        algorithm = ride_type_algo_map.get(ride_type, "fcfs")
        priority=scheduler.get_priority(ride_type)
        distance=max(1.0,round(scheduler.haversine(pickup_lat,pickup_lng,dropoff_lat,dropoff_lng)+random.uniform(0.5,3.0),2))
        fare=scheduler.calculate_fare(distance,ride_type)
        drivers=fetch_all("SELECT * FROM drivers WHERE status='available'")
        ride_data={"pickup_lat":pickup_lat,"pickup_lng":pickup_lng,"ride_type":ride_type,"priority":priority}
        best=scheduler.select_best_driver(drivers,ride_data,algorithm)
        eta=99; driver_id=None; status="queued"
        if best:
            eta=scheduler.estimate_eta(best["distance_to_pickup"],ride_type)
            driver_id=best["id"]; status="assigned"
            execute_db("UPDATE drivers SET status='busy' WHERE id=?",(driver_id,))
        ride_id=execute_db("INSERT INTO rides(user_id,driver_id,ride_type,status,pickup,dropoff,pickup_lat,pickup_lng,dropoff_lat,dropoff_lng,priority,fare,distance,eta,algorithm,burst_time,arrival_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))",
            (session["user_id"],driver_id,ride_type,status,pickup,dropoff,pickup_lat,pickup_lng,dropoff_lat,dropoff_lng,priority,fare,distance,eta,algorithm,int(distance),datetime.now().isoformat()))
        log_queue(ride_id,f"Ride booked via {algorithm.upper()}",algorithm)
        if best: log_queue(ride_id,f"Driver {best['name']} assigned (dist: {best['distance_to_pickup']}km)",algorithm)
        return jsonify({"success":True,"ride_id":ride_id,"status":status,"eta":eta,"fare":fare,"distance":distance,"driver":best["name"] if best else None,"driver_vehicle":best["vehicle"] if best else None,"algorithm":algorithm})
    return render_template("book.html")

@app.route("/ride/<int:ride_id>")
def ride_status(ride_id):
    if "user_id" not in session: return redirect(url_for("login"))
    ride=fetch_one("SELECT r.*,d.name as driver_name,d.vehicle,d.phone as driver_phone,d.rating as driver_rating FROM rides r LEFT JOIN drivers d ON r.driver_id=d.id WHERE r.id=?",(ride_id,))
    logs=fetch_all("SELECT * FROM queue_log WHERE ride_id=? ORDER BY timestamp",(ride_id,))
    return render_template("ride_status.html",ride=ride,logs=logs)

@app.route("/history")
def history():
    if "user_id" not in session: return redirect(url_for("login"))
    rides=fetch_all("SELECT r.*,d.name as driver_name,d.vehicle FROM rides r LEFT JOIN drivers d ON r.driver_id=d.id WHERE r.user_id=? ORDER BY r.created_at DESC",(session["user_id"],))
    return render_template("history.html",rides=rides)

# ─── ADMIN ROUTES ───────────────────────────────────────────────────────────

@app.route("/admin")
def admin_dashboard():
    if session.get("role")!="admin": return redirect(url_for("login"))
    stats={
        "total_rides":fetch_one("SELECT COUNT(*) as c FROM rides")["c"],
        "active_rides":fetch_one("SELECT COUNT(*) as c FROM rides WHERE status IN ('queued','assigned','ongoing')")["c"],
        "total_drivers":fetch_one("SELECT COUNT(*) as c FROM drivers")["c"],
        "avail_drivers":fetch_one("SELECT COUNT(*) as c FROM drivers WHERE status='available'")["c"],
        "total_revenue":round(fetch_one("SELECT COALESCE(SUM(fare),0) as s FROM rides WHERE status='completed'")["s"],2),
        "total_users":fetch_one("SELECT COUNT(*) as c FROM users WHERE role='user'")["c"],
    }
    recent_rides=fetch_all("SELECT r.*,u.name as user_name,d.name as driver_name FROM rides r LEFT JOIN users u ON r.user_id=u.id LEFT JOIN drivers d ON r.driver_id=d.id ORDER BY r.created_at DESC LIMIT 20")
    algo_stats=fetch_all("SELECT algorithm,COUNT(*) as count FROM rides GROUP BY algorithm")
    type_stats=fetch_all("SELECT ride_type,COUNT(*) as count FROM rides GROUP BY ride_type")
    return render_template("admin.html",stats=stats,recent_rides=recent_rides,algo_stats=algo_stats,type_stats=type_stats)

@app.route("/admin/queue")
def admin_queue():
    if session.get("role")!="admin": return redirect(url_for("login"))
    queued=fetch_all("SELECT r.*,u.name as user_name FROM rides r LEFT JOIN users u ON r.user_id=u.id WHERE r.status IN ('queued','assigned','ongoing') ORDER BY r.priority,r.arrival_time")
    return render_template("queue.html",rides=queued)

@app.route("/admin/drivers")
def admin_drivers():
    if session.get("role")!="admin": return redirect(url_for("login"))
    drivers=fetch_all("SELECT * FROM drivers ORDER BY status,rating DESC")
    return render_template("drivers.html",drivers=drivers)

@app.route("/driver/<int:driver_id>")
def driver_dashboard(driver_id):
    driver=fetch_one("SELECT * FROM drivers WHERE id=?",(driver_id,))
    if not driver: return redirect(url_for("login"))
    current_ride=fetch_one("SELECT r.*,u.name as user_name,u.phone as user_phone FROM rides r LEFT JOIN users u ON r.user_id=u.id WHERE r.driver_id=? AND r.status IN ('assigned','ongoing') ORDER BY r.created_at DESC LIMIT 1",(driver_id,))
    hist=fetch_all("SELECT r.*,u.name as user_name FROM rides r LEFT JOIN users u ON r.user_id=u.id WHERE r.driver_id=? AND r.status='completed' ORDER BY r.created_at DESC LIMIT 10",(driver_id,))
    return render_template("driver.html",driver=driver,current_ride=current_ride,history=hist)

# ─── API ────────────────────────────────────────────────────────────────────

@app.route("/api/queue")
def api_queue():
    algorithm=request.args.get("algorithm","priority")
    rides=fetch_all("SELECT r.*,u.name as user_name FROM rides r LEFT JOIN users u ON r.user_id=u.id WHERE r.status IN ('queued','assigned') ORDER BY r.created_at")
    if algorithm=="priority": rides=scheduler.priority_schedule(rides)
    elif algorithm=="fcfs": rides=scheduler.fcfs_schedule(rides)
    elif algorithm=="rr": rides=scheduler.round_robin_schedule(rides)
    elif algorithm=="sjf": rides=scheduler.sjf_schedule(rides)
    return jsonify({"rides":rides,"algorithm":algorithm})

@app.route("/api/ride/<int:ride_id>/status",methods=["POST"])
def update_ride_status(ride_id):
    new_status=request.json.get("status")
    ride=fetch_one("SELECT * FROM rides WHERE id=?",(ride_id,))
    if not ride: return jsonify({"error":"Not found"}),404
    if new_status=="completed":
        execute_db("UPDATE rides SET status=?,end_time=datetime('now') WHERE id=?",(new_status,ride_id))
        if ride["driver_id"]: execute_db("UPDATE drivers SET status='available',total_rides=total_rides+1 WHERE id=?",(ride["driver_id"],))
    elif new_status=="ongoing":
        execute_db("UPDATE rides SET status=?,start_time=datetime('now') WHERE id=?",(new_status,ride_id))
    else:
        execute_db("UPDATE rides SET status=? WHERE id=?",(new_status,ride_id))
        if new_status=="cancelled" and ride["driver_id"]:
            execute_db("UPDATE drivers SET status='available' WHERE id=?",(ride["driver_id"],))
    log_queue(ride_id,f"Status -> {new_status}",ride.get("algorithm",""))
    return jsonify({"success":True,"status":new_status})

@app.route("/api/ride/<int:ride_id>")
def api_ride(ride_id):
    ride=fetch_one("SELECT r.*,d.name as driver_name,d.vehicle,d.phone as driver_phone,d.rating as driver_rating FROM rides r LEFT JOIN drivers d ON r.driver_id=d.id WHERE r.id=?",(ride_id,))
    return jsonify(ride or {})

@app.route("/api/stats")
def api_stats():
    return jsonify({
        "by_type":fetch_all("SELECT ride_type,COUNT(*) as count FROM rides GROUP BY ride_type"),
        "by_algo":fetch_all("SELECT algorithm,COUNT(*) as count FROM rides GROUP BY algorithm"),
        "by_status":fetch_all("SELECT status,COUNT(*) as count FROM rides GROUP BY status"),
        "revenue":fetch_all("SELECT strftime('%Y-%m-%d',created_at) as day,SUM(fare) as total FROM rides WHERE status='completed' GROUP BY day ORDER BY day DESC LIMIT 7"),
    })

@app.route("/api/drivers")
def api_drivers():
    return jsonify({"drivers":fetch_all("SELECT * FROM drivers ORDER BY status,wait_time DESC")})

@app.route("/api/simulate")
def simulate_ride():
    types=["emergency","premium","normal","normal","normal","premium"]
    algos=["priority","fcfs","rr","sjf"]
    pickups=["Saddar, Karachi","DHA Phase 5","Gulshan-e-Iqbal","Clifton","Korangi","Nazimabad"]
    dropoffs=["Airport","University Road","Tariq Road","Burns Road","Shah Faisal Colony","Malir"]
    rt=random.choice(types); algo=random.choice(algos)
    plat=24.86+random.uniform(-0.05,0.05); plng=67.01+random.uniform(-0.05,0.05)
    dlat=24.88+random.uniform(-0.05,0.08); dlng=67.03+random.uniform(-0.05,0.08)
    priority=scheduler.get_priority(rt)
    dist=max(1.0,round(scheduler.haversine(plat,plng,dlat,dlng)+random.uniform(0.5,4.0),2))
    fare=scheduler.calculate_fare(dist,rt)
    drivers=fetch_all("SELECT * FROM drivers WHERE status='available'")
    best=scheduler.select_best_driver(drivers,{"pickup_lat":plat,"pickup_lng":plng,"ride_type":rt,"priority":priority},algo)
    user=fetch_one("SELECT id FROM users WHERE role='user' LIMIT 1"); user_id=user["id"] if user else 1
    eta=99; driver_id=None; status="queued"
    if best:
        eta=scheduler.estimate_eta(best["distance_to_pickup"],rt)
        driver_id=best["id"]; status="assigned"
        execute_db("UPDATE drivers SET status='busy' WHERE id=?",(driver_id,))
    ride_id=execute_db("INSERT INTO rides(user_id,driver_id,ride_type,status,pickup,dropoff,pickup_lat,pickup_lng,dropoff_lat,dropoff_lng,priority,fare,distance,eta,algorithm,burst_time,arrival_time) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))",
        (user_id,driver_id,rt,status,random.choice(pickups),random.choice(dropoffs),plat,plng,dlat,dlng,priority,fare,dist,eta,algo,int(dist),datetime.now().isoformat()))
    return jsonify({"ride_id":ride_id,"ride_type":rt,"algorithm":algo,"status":status,"fare":fare,"distance":dist})

@app.route("/api/auto_complete")
def auto_complete():
    old=fetch_all("SELECT * FROM rides WHERE status='assigned' AND datetime(created_at)<datetime('now','-5 minutes')")
    for r in old:
        execute_db("UPDATE rides SET status='completed',end_time=datetime('now') WHERE id=?",(r["id"],))
        if r["driver_id"]: execute_db("UPDATE drivers SET status='available',total_rides=total_rides+1 WHERE id=?",(r["driver_id"],))
    return jsonify({"completed":len(old)})

if __name__=="__main__":
    init_db()
    app.run(debug=True,port=5000)
